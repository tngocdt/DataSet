#!/usr/bin/env python
# coding: utf-8

# In[1]:


class xlsbreading:
    # need to install !pip install pyxlsb
    def __init__(self, searchfolder, extfile, keynamefile, sheetname, startword):
        self.searchfolder = searchfolder
        self.extfile = extfile
        self.keynamefile = keynamefile
        self.sheetname = sheetname
        self.startword = startword
        
    def xlsbreadingdata(self):            
        # **********************************************************************
        # Access folder
        import os
        searchkeyname_dict = {}
        listfiles = os.listdir(self.searchfolder)
        # print("Files and directories in '", self.searchfolder, "' :")
        # print(listfiles)       
        
        # **********************************************************************
        # Find specific *.xlsb file
        def isStringFound(x,y):
            try:
                x.upper().index(y.upper())
                return True
            except ValueError:
                return False
            
        searchkeyname_dict['ext'] = self.extfile
        searchkeyname_dict['keyword'] = self.keynamefile
        searchkeyname_dict['sheetname'] = self.sheetname
        searchkeyname_dict['startword'] = self.startword
        # print(searchkeyname_dict.keys())
        # print(searchkeyname_dict.values())
        # print(searchkeyname_dict['ext'])
        # print(searchkeyname_dict['startword'])
        
        # **********************************************************************
        dictfile = {}
        tuplekey = {'fname','mdate'}
        listfname = []
        listmdate = []
        for x in os.listdir(searchfolder):
            if x.endswith(searchkeyname_dict['ext'][0]):
                pathfile = searchfolder + "\\" +  x
                fileinfor = "File name is: {0}, Modified time is: {1}".format(x,os.path.getmtime(pathfile))
                # print(fileinfor)
                if x.upper().startswith(searchkeyname_dict['startword'].upper()):
                    for y in searchkeyname_dict['keyword']:
                        if(isStringFound(x,y)):
                            if x not in listfname:
                                listfname.append(x)
                                listmdate.append(os.path.getmtime(pathfile))

        dictfile['fname'] = listfname
        dictfile['mdate'] = listmdate
        # print()
        # print(dictfile.keys())
        # print(dictfile.values())
        
        # **********************************************************************
        # Import & Install Excel *.xlsb Utility
        import pandas as pd
        # Find The Correct *.xlsb File With Specific SheetName
        dffile = pd.DataFrame(dictfile, columns=dictfile.keys())
        # print(dffile.sort_values(by=['mdate'], ascending = False))
        sheetname = searchkeyname_dict['sheetname']
        # print(sheetname[0])
        from pyxlsb import open_workbook as open_xlsb

        foundfile = "notfound"
        foundsheetname = "notfound"
        for index, row in dffile.sort_values(by=['mdate'], ascending = False).iterrows():
            pathfile = searchfolder + "\\" +  row['fname']
            with open_xlsb(pathfile) as wb:
                for x in sheetname:
                    if x in (wb.sheets):
                        foundfile = pathfile
                        foundsheetname = x
                        break
                if (foundfile != "notfound"):
                    break
        # print(foundfile)
        
        # **********************************************************************
        # Read *.xlsb to DataFrame object
        dfleanrpt = pd.read_excel(foundfile, sheet_name=foundsheetname, engine='pyxlsb')
        # print(dfleanrpt[2:3])
        # print(dfleanrpt.index)
        # print(dfleanrpt.columns)
        # print(dfleanrpt.loc[[1,2],['No','Project ID']])
        
        # Iterate Rows In DataFrame
        #for index, row in dfleanrpt.iterrows():
        #    print(row['No'], row['Project ID'])
                
        # Apply Modifications in SQL Server
        import numpy as np
        from datetime import datetime
        import datetime, xlrd
        import math
        
        def isfloat(num):
            try:
                float(num)
                return True
            except ValueError:
                return False
        
        # **********************************************************************
        # Connect to MSSQL
        import pyodbc
        try:
            cnxn_str = ("Driver={SQL Server Native Client 11.0};"
                        "Server=vnhcmm0ieapp01\sqlexpress;"
                        "Database=IESupportDB;"
                        "UID=ie;"
                        "PWD=J@bil*1111;")
            cnxn = pyodbc.connect(cnxn_str)
            cursor = cnxn.cursor()
            # detele all old data
            cursor.execute("DELETE FROM [IESupportDB].[dbo].[07_LEAN_Project_Report]")
            cnxn.commit()
            
            # now update that column to contain firstName + lastName
            intID = 0
            strprojectID = ""

            for index, row in dfleanrpt.iterrows():
                intID+=1
                strprojectID = str(int(row['Project ID'])).strip()
                                
                strprojectURL = "None"
                if ('URL' in dfleanrpt.index):
                    strprojectURL = "\'" + str(row['URL']).strip().replace('\'','') + "\'"
                else:
                    strprojectURL = "\'" + "None" + "\'"
                    
                strprojectEmailLeader = "\'" + str(row['Email leader']).strip().replace('\'','') + "\'"

                dtprojectSubmittedDate = np.NaN   
                if (isfloat(row['Submitted Date'])):
                    if(math.isnan(row['Submitted Date'])):
                        dtprojectSubmittedDate = 'null'            
                    else:
                        datetime_date = xlrd.xldate_as_datetime(row['Submitted Date'], 0)
                        date_object = datetime_date.date()
                        dtprojectSubmittedDate = "\'" + date_object.isoformat() + "\'"
                else:
                    dtprojectSubmittedDate = 'null'

                dtprojectClosedDate = np.NaN   
                if (isfloat(row['Closed Date'])):
                    if(math.isnan(row['Closed Date'])):
                        dtprojectClosedDate = 'null'            
                    else:
                        datetime_date = xlrd.xldate_as_datetime(row['Closed Date'], 0)
                        date_object = datetime_date.date()
                        dtprojectClosedDate = "\'" + date_object.isoformat() + "\'"
                else:
                    dtprojectClosedDate = 'null'

                strprojectFunction = "\'" + str(row['Function']).strip().replace('\'','') + "\'"
                strprojectWC = "\'" + str(row['WC']).strip().replace('\'','') + "\'"
                strprojectCustomer = "\'" + str(row['Customer']).strip().replace('\'','') + "\'"
                strprojectType = "\'" + str(row['Project type']).strip().replace('\'','') + "\'"

                decprojectEstimatedHardSaving = 0
                if (isfloat(row['Hardsaving estimated'])):
                    decprojectEstimatedHardSaving = float(row['Hardsaving estimated'])
                decprojectEstimatedHardSaving = "\'" + str(decprojectEstimatedHardSaving) + "\'"

                decprojectValidatedHardSaving = 0
                if (isfloat(row['Hard saving validated'])):
                    decprojectValidatedHardSaving = float(row['Hard saving validated'])
                decprojectValidatedHardSaving = "\'" + str(decprojectValidatedHardSaving) + "\'"

                decprojectValidatedSoftSaving = 0
                if (isfloat(row['Soft saving validated'])):
                    decprojectValidatedSoftSaving = float(row['Soft saving validated'])
                decprojectValidatedSoftSaving = "\'" + str(decprojectValidatedSoftSaving) + "\'"

                strprojectName = "\'" + str(row['Project name']).strip().replace('\'','') + "\'"
                strprojectStatus = "\'" + str(row['Status']).strip().replace('\'','') + "\'"
                
                dtprojectClosedMonth = np.NaN   
                if (isfloat(row['Month Closed'])):
                    if(math.isnan(row['Month Closed'])):
                        dtprojectClosedMonth = 'null'            
                    else:
                        datetime_date = xlrd.xldate_as_datetime(row['Month Closed'], 0)
                        date_object = datetime_date.date()
                        dtprojectClosedMonth = "\'" + date_object.isoformat() + "\'"
                else:
                    dtprojectClosedMonth = 'null'


                strprojectPnL = "\'" + str(row['Impact on P&L']).strip().replace('\'','') + "\'"
                strprojectValidatePnL = "\'" + str(row['Validate P&L']).strip().replace('\'','') + "\'"
                strprojectTAG1 = "\'" + str(row['TAG1']).strip().replace('\'','') + "\'"
                strprojectTAG2 = "\'" + str(row['TAG2']).strip().replace('\'','') + "\'"
                strprojectTAG3 = "\'" + str(row['TAG3']).strip().replace('\'','') + "\'"
                strprojectTAG4 = "\'" + str(row['TAG4']).strip().replace('\'','') + "\'"
                strprojectFoF = "\'" + str(row['FOF']).strip().replace('\'','') + "\'"
                
                queryprefix = "INSERT INTO [IESupportDB].[dbo].[07_LEAN_Project_Report](ID,ProjectID,ProjectURL,ProjectEmailLeader,ProjectSubmitedDate,ProjectClosedDate,ProjectFunction,ProjectWC,ProjectCustomer,ProjectType,ProjectEstimatedHardSaving,ProjectValidatedHardSaving,ProjectValidatedSoftSaving,ProjectName,ProjectStatus,ProjectClosedMonth,ProjectPnL,ProjectValidatePnL,ProjectTAG1,ProjectTAG2,ProjectTAG3,ProjectTAG4,ProjectFoF) VALUES("
                query = "{0}{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19},{20},{21},{22},{23})".format(queryprefix,str(intID),strprojectID,strprojectURL,strprojectEmailLeader,dtprojectSubmittedDate,dtprojectClosedDate,strprojectFunction,strprojectWC,strprojectCustomer,strprojectType,decprojectEstimatedHardSaving,decprojectValidatedHardSaving,decprojectValidatedSoftSaving,strprojectName,strprojectStatus,dtprojectClosedMonth,strprojectPnL,strprojectValidatePnL,strprojectTAG1,strprojectTAG2,strprojectTAG3,strprojectTAG4,strprojectFoF)
                cursor.execute(query)

                # end the connection
                cnxn.commit()
            
            return {'result': 'PASS', 'fname': foundfile}
        except ValueError as e:
            return {'result': "Error: " + str(e) + ". At Project ID: " + str(strprojectID), 'fname': foundfile}


# In[2]:


searchfolder = r'\\hcmfile02\!General_05Y\12.LEAN\02.LEAN - Public\7.Lean share folder\FY23'
# searchfolder = r'\\vnhcmm0ieapp01\Sharedtngo\02_Python_AutoJob\01_Python_LSS'
extfile = ['xlsb']
keynamefile = ['lean kpi', 'tracker']
sheetname = ['Data Consolidate']
startword = 'lean'

xlsbreadingobj = xlsbreading(searchfolder, extfile, keynamefile, sheetname, startword)
result = xlsbreadingobj.xlsbreadingdata()


# In[5]:


from datetime import datetime

now = datetime.now()
# dd/mm/YY H:M:S
dt_string = now.strftime("%d/%m/%Y %H:%M:%S")

resultlogpath = r'\\vnhcmm0ieapp01\Sharedtngo\02_Python_AutoJob\01_Python_LSS'
resultlogfname = "leanrpt.txt"
resultpathfile = resultlogpath + "\\" +  resultlogfname
# print(resultpathfile)

with open(resultpathfile, 'a') as f:
    f.write(dt_string + '\t' + result['fname'] + '\t' + result['result'])
    f.write('\n')


# In[6]:


import os
import smtplib
from smtplib import SMTP
from email import encoders
from email.message import Message
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from datetime import datetime

# date = date.strftime("%Y-%m-%d")  # convert to format yyyy-mm-dd

# write an email message
message = (dt_string + ": " + '\t' + result['fname'] + '\t' + result['result'])
# print(message)
# we will built the message using the email library and send using smtplib
msg = MIMEMultipart('alternative')
msg['Subject'] = "LSS Python Report - " + dt_string   # set email subject

directory = r"\\vnhcmm0ieapp01\Sharedtngo\02_Python_AutoJob\01_Python_LSS"
filename = "leanrpt.txt"
path = os.path.join(directory, filename)
img = MIMEImage(open(path, 'rb').read(), _subtype="txt")
img.add_header('Content-Disposition', 'attachment', filename=filename)
msg.attach(img)

# msg.attach(MIMEText(txt))  # add text contents
# part = MIMEText(message, "plain")
# part.set_payload(message)
# msg.attach(part)

html = """
<html>
<head></head>
  <body>
    <p>""" + dt_string + ": " + result['result'] + """</p>
    <a href=""" + "\"" + result['fname'] + "\"" + ">" + result['fname'] + """</a>
  </body>
</html>
"""
part = MIMEText(html,'html')
msg.attach(part)
       
# we will send via outlook, first we initialise connection to mail server
# smtp = smtplib.SMTP('smtp-mail.outlook.com', '587')
with SMTP("corimc04.corp.jabil.org") as smtp:
    smtp.ehlo()  # say hello to the server
    smtp.starttls()  # we will communicate using TLS encryption
       
    # login to outlook server, using generic email and password
    # smtp.login('Alex@outlook.com', 'Alex123')
       
    # send email to our boss
    smtp.sendmail('noreply_autopython_leanrpt@jabil.com', 'truong_ngo@jabil.com', msg.as_string())


# In[ ]:




