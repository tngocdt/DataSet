#!/usr/bin/env python
# coding: utf-8

# # Execution Module

# ## OKTAToken Access Module

# In[1]:


class OKTAToken:
    # url = "https://jabil.okta.com/oauth2/default/v1/token"
    def __init__(self, url):
        self.url = url
        
    def postaccesstoken(self):
        # importing the requests library
        import requests
        import json
        
        # defining the api-endpoint 
        API_ENDPOINT = self.url
        
        # data to be sent to api
        data = {'grant_type': 'client_credentials',
                'scope': 'access_token',
                'client_id':'0oagwd7ekglCGkNf62p7',
                'client_secret': '-o0zB4nn_j1dbakJQ8jZVH2t77aqPCgNyS0lHqxD'}

        # sending post request and saving response as response object
        r = requests.post(url = API_ENDPOINT, data = data)

        # extracting response text 
        pastebin_url = r.text
        res = json.loads(pastebin_url)
        # print(pastebin_url)
        strtoken = res['access_token']
        return {'access_token': strtoken}
    
class IEDBAPI:
    # url = "https://jabil.okta.com/oauth2/default/v1/token"
    def __init__(self, url, accesstoken, getapi, site, customer, assysku, assyrev):
        self.url = url
        self.accesstoken = accesstoken
        self.getapi = getapi
        self.site = site
        self.customer = customer
        self.assysku = assysku
        self.assyrev = assyrev
        
    def getGRPSummaryReport(self):
        # importing the requests library
        import pandas as pd
        import requests
        import json
        
        # api-endpoint
        URL = self.getapi
        
        # header
        bearertoken = "Bearer " + self.accesstoken
        headers = {"Authorization": bearertoken}

        # defining a params dict for the parameters to be sent to the API
        site = self.site
        customer = self.customer
        division = customer + "*"
        PARAMS = {'site': site,
                  'customer': customer,
                  'division': division}

        # sending get request and saving the response as response object
        r = requests.get(url = URL, headers=headers, params = PARAMS)

        # extracting data in json format
        data = r.text
        json_dict = json.loads(data)
        
        # converting json dictionary to python dataframe for results object
        df = pd.DataFrame.from_dict(json_dict)
        result = df['Result'][0]
        df2 = pd.DataFrame.from_dict(result)
        return df2
    
    def getAssemblyUpdateReport(self):
        # importing the requests library
        import pandas as pd
        import requests
        import json
        
        # api-endpoint
        URL = self.getapi
        
        # header
        bearertoken = "Bearer " + self.accesstoken
        headers = {"Authorization": bearertoken}

        # defining a params dict for the parameters to be sent to the API
        site = self.site
        customer = self.customer
        division = customer + "*"
        PARAMS = {'site': site,
                  'customer': customer,
                  'division': division}

        # sending get request and saving the response as response object
        r = requests.get(url = URL, headers=headers, params = PARAMS)

        # extracting data in json format
        data = r.text
        json_dict = json.loads(data)
        
        # converting json dictionary to python dataframe for results object
        df = pd.DataFrame.from_dict(json_dict)
        result = df['Result'][0]
        df2 = pd.DataFrame.from_dict(result)
        return df2
    
    def getRawDataReport(self):
        # importing the requests library
        import pandas as pd
        import requests
        import json
        
        # api-endpoint
        URL = self.getapi
        
        # header
        bearertoken = "Bearer " + self.accesstoken
        headers = {"Authorization": bearertoken}

        # defining a params dict for the parameters to be sent to the API
        site = self.site
        customer = self.customer
        division = customer + "*"
        PARAMS = {'site': site,
                  'customer': customer,
                  'division': division,
                  'assembly': assysku,
                  'revision': assyrev}
       
        # sending get request and saving the response as response object
        r = requests.get(url = URL, headers=headers, params = PARAMS)

        # extracting data in json format
        data = r.text
        json_dict = json.loads(data)
        
        # converting json dictionary to python dataframe for results object
        df = pd.DataFrame.from_dict(json_dict)
        # print(df)
        result = df['Result']
        return result


# ## IEDB API "AssemblyUpdate" Execution Module

# In[2]:


class IEDBRawDataUpdate:
    # url = "https://jabil.okta.com/oauth2/default/v1/token"
    def __init__(self, site, customer, division, customerid, assysku, assyrev, assyworkcenter, assysubworkcenter, assyprocess, assypriority, assyorder, assygrp, assyfamily, assylct, assymach, assyimt, assyhand, assypb, assyhc, assycap, assygl, assysample, assytype):
        self.site = site
        self.customer = customer
        self.division = division
        self.customerid = customerid
        self.assysku = assysku
        self.assyrev = assyrev
        self.assyworkcenter = assyworkcenter
        self.assysubworkcenter =assysubworkcenter
        self.assyprocess = assyprocess
        self.assypriority = assypriority
        self.assyorder = assyorder
        self.assygrp = assygrp
        self.assyfamily = assyfamily
        self.assylct = assylct
        self.assymach = assymach
        self.assyimt = assyimt
        self.assyhand = assyhand
        self.assypb = assypb
        self.assyhc = assyhc
        self.assycap = assycap
        self.assygl = assygl
        self.assysample = assysample
        self.assytype = assytype
        
    def accessIEDBCustomerID(self):
        import pandas as pd
        import sqlalchemy as sa
        import urllib
        from sqlalchemy import create_engine, event
        from sqlalchemy.engine.url import URL
        from sqlalchemy.sql import text

        # https://hevodata.com/learn/python-sql-server-integration/
        server = 'vnhcmm0ieapp01\sqlexpress' 
        database = 'IESupportDB' 
        username = 'ie' 
        password = 'J@bil*1111' 

        params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                                         "SERVER="+server+";"
                                         "DATABASE="+database+";"
                                         "UID="+username+";"
                                         "PWD="+password+";")

        engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))

        qry = "SELECT TOP(1) * FROM [IESupportDB].[dbo].[08_IEDB_vs_PLANT_WorkcellID] WHERE IEDBCustomer = '" + self.customer + "' AND IEDBSite = '" + self.site + "' AND IEDBDivision = '" + self.division + "'"

        with engine.connect() as conn:
            rs = conn.execute(qry)
            # dfiedb = pd.DataFrame(rs.fetchall())
            dfiedb = pd.read_sql(qry, con = conn)
        
        return dfiedb
        
    def accessIEDBAssemblyRpt(self):
        import pandas as pd
        import sqlalchemy as sa
        import urllib
        from sqlalchemy import create_engine, event
        from sqlalchemy.engine.url import URL
        from sqlalchemy.sql import text

        # https://hevodata.com/learn/python-sql-server-integration/
        server = 'vnhcmm0ieapp01\sqlexpress' 
        database = 'IESupportDB' 
        username = 'ie' 
        password = 'J@bil*1111' 

        params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                                         "SERVER="+server+";"
                                         "DATABASE="+database+";"
                                         "UID="+username+";"
                                         "PWD="+password+";")

        engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))

        qry = "SELECT [IEDBCustomerID], [IEDBCustomer], [IEDBSite], [IEDBDivision], [IEDBAssembly], [IEDBRevision] FROM [IESupportDB].[dbo].[v_08_IEDB_vs_AssemblyUpdateReportUni] WHERE IEDBCustomer = '" + self.customer + "' AND IEDBSite = '" + self.site + "' AND IEDBDivision = '" + self.division + "'"

        with engine.connect() as conn:
            rs = conn.execute(qry)
            # dfiedb = pd.DataFrame(rs.fetchall())
            dfiedb = pd.read_sql(qry, con = conn)
        
        return dfiedb
    
    def accessIEDBRawDataUpdate(self):
        import pandas as pd
        import sqlalchemy as sa
        import urllib
        from sqlalchemy import create_engine, event
        from sqlalchemy.engine.url import URL
        from sqlalchemy.sql import text

        # https://hevodata.com/learn/python-sql-server-integration/
        server = 'vnhcmm0ieapp01\sqlexpress' 
        database = 'IESupportDB' 
        username = 'ie' 
        password = 'J@bil*1111' 

        params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                                         "SERVER="+server+";"
                                         "DATABASE="+database+";"
                                         "UID="+username+";"
                                         "PWD="+password+";")

        engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))

        qry = "SELECT TOP(1) * FROM [IESupportDB].[dbo].[08_IEDB_vs_RawDataUni] WHERE IEDBCustomerID = '" + str(self.customerid) + "' AND IEDBAssembly = '" + str(self.assysku) + "' AND IEDBRevision = '" + str(self.assyrev) + "' AND IEDBWorkcenter = '" + str(self.assyworkcenter) + "' AND IEDBSubWorkcenter = '" + str(self.assysubworkcenter) + "' AND IEDBProcess = '" + str(self.assyprocess) + "' AND IEDBPriority = '" + str(self.assypriority) + "' AND IEDBOrder = '" + str(self.assyorder) + "' AND IEDBGRP = '" + str(self.assygrp) + "'"

        with engine.connect() as conn:
            rs = conn.execute(qry)
            # dfiedb = pd.DataFrame(rs.fetchall())
            dfiedb = pd.read_sql(qry, con = conn)
        
        return dfiedb
    
    def insertIEDBRawDataUni(self):
        import pandas as pd
        import sqlalchemy as sa
        import urllib
        from sqlalchemy import create_engine, event
        from sqlalchemy.engine.url import URL
        from sqlalchemy.sql import text
        from sqlalchemy.exc import DataError, IntegrityError
        
        errormsg = "NO"
        # https://hevodata.com/learn/python-sql-server-integration/
        server = 'vnhcmm0ieapp01\sqlexpress' 
        database = 'IESupportDB' 
        username = 'ie' 
        password = 'J@bil*1111' 

        params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                                         "SERVER="+server+";"
                                         "DATABASE="+database+";"
                                         "UID="+username+";"
                                         "PWD="+password+";")

        engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))

        qry = "INSERT INTO [IESupportDB].[dbo].[08_IEDB_vs_RawDataUni]([IEDBCustomerID], [IEDBAssembly], [IEDBRevision], [IEDBWorkcenter], [IEDBSubWorkcenter], [IEDBProcess], [IEDBPriority], [IEDBOrder], [IEDBGRP], [IEDBFamily], [IEDBLCT], [IEDBMach], [IEDBIMT], [IEDBHand], [IEDBPB], [IEDBHC], [IEDBCAP], [IEDBGL], [IEDLSample], [IEDBType]) VALUES ('" + str(self.customerid) + "', '" + str(self.assysku) + "', '" + str(self.assyrev) + "', '" + str(self.assyworkcenter) + "', '" + str(self.assysubworkcenter) + "', '" + str(self.assyprocess) + "', '" + str(self.assypriority) + "', '" + str(self.assyorder) + "', '" + str(self.assygrp) + "', '" + str(self.assyfamily) + "', '" + str(self.assylct) + "', '" + str(self.assymach) + "', '" + str(self.assyimt) + "', '" + str(self.assyhand) + "', '" + str(self.assypb) + "', '" + str(self.assyhc) + "', '" + str(self.assycap) + "', '" + str(self.assygl) + "', '" + str(self.assysample) + "', '" + str(self.assytype) + "')"
        
        with engine.connect() as conn:
            try:
                conn.execute(qry)
            except IntegrityError as e:
                # print(e.orig)
                errormsg = e.statement
                pass
        return errormsg
    
    def insertIEDBRawDataDup(self):
        import pandas as pd
        import sqlalchemy as sa
        import urllib
        from sqlalchemy import create_engine, event
        from sqlalchemy.engine.url import URL
        from sqlalchemy.sql import text
        from sqlalchemy.exc import DataError, IntegrityError
        
        errormsg = "NO"
        # https://hevodata.com/learn/python-sql-server-integration/
        server = 'vnhcmm0ieapp01\sqlexpress' 
        database = 'IESupportDB' 
        username = 'ie' 
        password = 'J@bil*1111' 

        params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                                         "SERVER="+server+";"
                                         "DATABASE="+database+";"
                                         "UID="+username+";"
                                         "PWD="+password+";")

        engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))

        qry = "INSERT INTO [IESupportDB].[dbo].[08_IEDB_vs_RawDataUni]([IEDBCustomerID], [IEDBAssembly], [IEDBRevision], [IEDBWorkcenter], [IEDBSubWorkcenter], [IEDBProcess], [IEDBPriority], [IEDBOrder], [IEDBGRP], [IEDBFamily], [IEDBLCT], [IEDBMach], [IEDBIMT], [IEDBHand], [IEDBPB], [IEDBHC], [IEDBCAP], [IEDBGL], [IEDLSample], [IEDBType]) VALUES ('" + str(self.customerid) + "', '" + str(self.assysku) + "', '" + str(self.assyrev) + "', '" + str(self.assyworkcenter) + "', '" + str(self.assysubworkcenter) + "', '" + str(self.assyprocess) + "', '" + str(self.assypriority) + "', '" + str(self.assyorder) + "', '" + str(self.assygrp) + "', '" + str(self.assyfamily) + "', '" + str(self.assylct) + "', '" + str(self.assymach) + "', '" + str(self.assyimt) + "', '" + str(self.assyhand) + "', '" + str(self.assypb) + "', '" + str(self.assyhc) + "', '" + str(self.assycap) + "', '" + str(self.assygl) + "', '" + str(self.assysample) + "', '" + str(self.assytype) + "')"

        with engine.connect() as conn:
            try:
                conn.execute(qry)
            except IntegrityError as e:
                # print(e.orig)
                errormsg = e.statement
                pass
        return errormsg
    
    def deleteIEDBRawData(self):
        import pandas as pd
        import sqlalchemy as sa
        import urllib
        from sqlalchemy import create_engine, event
        from sqlalchemy.engine.url import URL
        from sqlalchemy.sql import text

        # https://hevodata.com/learn/python-sql-server-integration/
        server = 'vnhcmm0ieapp01\sqlexpress' 
        database = 'IESupportDB' 
        username = 'ie' 
        password = 'J@bil*1111' 

        params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                                         "SERVER="+server+";"
                                         "DATABASE="+database+";"
                                         "UID="+username+";"
                                         "PWD="+password+";")

        engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))

        qry1 = "DELETE FROM [IESupportDB].[dbo].[08_IEDB_vs_RawDataUni] WHERE IEDBCustomerID = '" + str(self.customerid) + "'"
        qry2 = "DELETE FROM [IESupportDB].[dbo].[08_IEDB_vs_RawDataDup] WHERE IEDBCustomerID = '" + str(self.customerid) + "'"
        with engine.connect() as conn:
            conn.execute(qry1)
            conn.execute(qry2)
            
# iedbCustomerAPI = IEDBCustomerID('HCM','HCM_CALIX','HCM_CALIX*','','','','','','')
# apiCustomerres = iedbCustomerAPI.accessIEDBCustomerID()
# print(apiCustomerres['IEDBCustomerID'][0])


# # Iterate The IEDB Workcel Division

# In[3]:


import pandas as pd
import sqlalchemy as sa
import urllib
from sqlalchemy import create_engine, event
from sqlalchemy.engine.url import URL
from sqlalchemy.sql import text
from sqlalchemy.exc import DataError, IntegrityError

from datetime import datetime
from openpyxl import Workbook
from openpyxl import load_workbook

# log data time start time report
dtStartProgress = datetime.now()

# log data time report
now = datetime.now()
# dd/mm/YY H:M:S
dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
dt_string2 = now.strftime("%Y%m%d_%H%M%S")
storedfolder = r'\\vnhcmm0ieapp01\Sharedtngo\02_Python_AutoJob\02_Python_IEDB'
resultlogfname = "iedbassyrawdatarpt.txt"
resultpathfile = storedfolder + "\\" +  resultlogfname
# open(resultpathfile, 'w').close()

# https://hevodata.com/learn/python-sql-server-integration/
server = 'vnhcmm0ieapp01\sqlexpress' 
database = 'IESupportDB' 
username = 'ie' 
password = 'J@bil*1111' 

params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                                 "SERVER="+server+";"
                                 "DATABASE="+database+";"
                                 "UID="+username+";"
                                 "PWD="+password+";")

engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))

qry = "SELECT * FROM [IESupportDB].[dbo].[08_IEDB_vs_PLANT_WorkcellID]"

with engine.connect() as conn:
    rs = conn.execute(qry)
    # dfiedb = pd.DataFrame(rs.fetchall())
    dfiedb = pd.read_sql(qry, con = conn)

print(dfiedb)


# # ETL: IEDB Assembly Update From IEDB

# In[4]:


from datetime import datetime

storedfolder = r'\\vnhcmm0ieapp01\Sharedtngo\02_Python_AutoJob\02_Python_IEDB'
resultlogfname = "iedbassyrawdatarpt.txt"
resultpathfile = storedfolder + "\\" +  resultlogfname
# open(resultpathfile, 'w').close()

apiresult = 'PASS'
apieachresult = 'PASS'
    
now = datetime.now()
dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
    
customer = 'HCM_CALIX'  # row['IEDBCustomer'].strip()
site = 'HCM'          # row['IEDBSite'].strip()
division = 'HCM_CALIX*' # row['IEDBDivision'].strip()
wcid = 1              # row['PLWorkcellID']
errormsg = "NO"
resultotal = ""
    
try:
    # Access The IEDBRawDataUpdate
    sqlCustomer = IEDBRawDataUpdate(site, customer, division, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
    sqlCustomerRes = sqlCustomer.accessIEDBAssemblyRpt()
    # print(sqlCustomerRes)
    intCustomerID = sqlCustomerRes['IEDBCustomerID'][0]
    # print(str(intCustomerID) + ": " + customer)
    # Delete The Current IEDBCustomerID In Database
    iedbDeleteRawDataAPI = IEDBRawDataUpdate(site, customer, division, intCustomerID, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
    iedbDeleteRawDataAPI.deleteIEDBRawData()

    x = customer.find('_')
    cust = customer[(x+1):len(customer)] 
    # print(str(intCustomerID) + ': ' + customer)
    
    rowassy = 0
        
    # access OKTA token
    url = "https://jabil.okta.com/oauth2/default/v1/token"
    oktatoken = OKTAToken(url)
    accesstoken = oktatoken.postaccesstoken()

    for indexsql, rowsql in sqlCustomerRes.iterrows():
        rowassy = rowassy + 1
        assysku = str(rowsql['IEDBAssembly']).strip().replace("'","")
        assyrev = str(rowsql['IEDBRevision']).strip().replace("'","")
        # print(str(intCustomerID) + ': ' + customer +  '\t'1 + str(rowassy) + " assysku: " + str(assysku) + " assyrev: " + str(assyrev) )

        # execute IEDB API
        try:
            getapi = "https://iedb2api-prd.jblapps.com/api/Report/GetRawDataReport"
            iedbapi = IEDBAPI(url, accesstoken['access_token'], getapi, site, customer, assysku, assyrev)
            apiRawDataRes = iedbapi.getRawDataReport()
            
            # populate to sqlserver
            # print(apiRawDataRes)
            for rowapi in apiRawDataRes:
                #print(rowapi])
                assyworkcenter = str(rowapi['Workcenter']).strip().replace("'","")
                assysubworkcenter = str(rowapi['SubWorkcenter']).strip().replace("'","")
                assyprocess = str(rowapi['Process']).strip().replace("'","")
                assypriority = rowapi['Priority']
                assyorder = rowapi['Order']
                assygrp = rowapi['GRP']
                assyfamily = str(rowapi['Family']).strip().replace("'","")

                assyrevres = str(rowapi['Revision']).strip().replace("'","")
                
                # ***************************************************
                # Cycle time transofmration
                assylct = rowapi['LCT']
                if (assylct is None):
                    assylct = 0

                assymach = rowapi['Mach']
                if (assymach is None):
                    assymach = 0

                assyimt = rowapi['IMT']
                if (assyimt is None):
                    assyimt = 0

                assyhand = rowapi['Hand']
                if (assyhand is None):
                    assyhand = 0

                assytotaltime = assylct + assymach + assyimt + assyhand

                # ***************************************************
                assypb = rowapi['PB']
                if (assypb is None):
                    assypb = 0
                        
                assyhc = rowapi['HC']
                if (assyhc is None):
                    assyhc = 0
                    
                assycap = rowapi['CAP']
                assygl = str(rowapi['GL']).strip().replace("'","")
                assysample = rowapi['Sperc']
                assytype = str(rowapi['Type']).strip().replace("'","")

                if((assytotaltime > 0) and (assyrev == assyrevres)):
                    iedbCustomerAPI = IEDBRawDataUpdate(site, customer, division, intCustomerID, assysku, assyrev, assyworkcenter, assysubworkcenter, assyprocess, assypriority, assyorder, assygrp, assyfamily, assylct, assymach, assyimt, assyhand, assypb, assyhc, assycap, assygl, assysample, assytype)
                    dfIEDBRawDataUpdate = iedbCustomerAPI.accessIEDBRawDataUpdate()
                    if (len(dfIEDBRawDataUpdate) > 0):
                        errormsg = iedbCustomerAPI.insertIEDBRawDataUni()
                        if(errormsg != "NO"):
                            break                          
                    else:
                        errormsg = iedbCustomerAPI.insertIEDBRawDataUni()
                        if(errormsg != "NO"):
                            break
                                
        except ValueError:
            apieachresult = 'FAIL'
            # write overall result to txt file
            with open(resultpathfile, 'a') as f:
                resultotal = dt_string + '\t' + "FAIL" + '\t' + cust + "_AssemblyRawDataRpt" + '\t\t' + str(assysku) + '\t\t' + assyrev + '\t\t' + str(ValueError)
                f.write(resultotal)
                f.write('\n')
            errormsg = "YES"
            pass
        
        if(errormsg != "NO"):
            break  
            
    if(errormsg == "NO"):
        # write overall result to txt file
        with open(resultpathfile, 'a') as f:
            resultotal = dt_string + '\t' + "PASS" + '\t' + cust + "_AssemblyRawDataRpt"
            f.write(resultotal)
            f.write('\n')
    else:
        apieachresult = 'FAIL'
        # write overall result to txt file
        with open(resultpathfile, 'a') as f:
            resultotal = dt_string + '\t' + "FAIL" + '\t' + cust + "_AssemblyRawDataRpt" + '\t\t' + str(errormsg)
            f.write(resultotal)
            f.write('\n') 
            
except ValueError:
    apieachresult = 'FAIL'
    # write overall result to txt file
    with open(resultpathfile, 'a') as f:
        resultotal = dt_string + '\t' + "FAIL" + '\t' + cust + "_AssemblyRawDataRpt" + '\t\t' + str(ValueError)
        f.write(resultotal)
        f.write('\n')
    pass

if(apieachresult == 'FAIL'):
    apiresult = 'FAIL'
print(resultotal)
    
dtEndProgress = datetime.now()
diffexetime = (dtEndProgress - dtStartProgress).total_seconds()
with open(resultpathfile, 'a') as f:
    f.write("dtStartProgress: " + '\t' + dtStartProgress.strftime("%d/%m/%Y %H:%M:%S") + '\t\t' + "dtEndProgress: " + dtEndProgress.strftime("%d/%m/%Y %H:%M:%S") + '\t\t' + "diffexetime: " + str(diffexetime) + " (secs)")
    f.write('\n')


# # SMTP Email Progress

# In[9]:


import os
import smtplib
from smtplib import SMTP
from email import encoders
from email.message import Message
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from datetime import datetime

# date = date.strftime("%Y-%m-%d")  # convert to format yyyy-mm-dd

# print(message)
# we will built the message using the email library and send using smtplib
msg = MIMEMultipart('alternative')
msg['Subject'] = "IEDB GetRawData Python - " + dt_string   # set email subject

directory = r"\\vnhcmm0ieapp01\Sharedtngo\02_Python_AutoJob\02_Python_IEDB"
filename = "iedbassyrawdatarpt.txt"
path = os.path.join(directory, filename)
img = MIMEImage(open(path, 'rb').read(), _subtype="txt")
img.add_header('Content-Disposition', 'attachment', filename=filename)
msg.attach(img)

# write an email message
message = ''
count = 0
with open(path) as f:
    for line in f:
        count += 1
        message = message + '\n' + str(count) + '\t' + line

part = MIMEText(message,'plain')
msg.attach(part)
       
# we will send via outlook, first we initialise connection to mail server
# smtp = smtplib.SMTP('smtp-mail.outlook.com', '587')
with SMTP("corimc04.corp.jabil.org") as smtp:
    smtp.ehlo()  # say hello to the server
    smtp.starttls()  # we will communicate using TLS encryption
       
    # login to outlook server, using generic email and password
    # smtp.login('Alex@outlook.com', 'Alex123')
       
    # send email to our boss
    smtp.sendmail('noreply_autopyiedb_RawDataRpt@jabil.com', 'truong_ngo@jabil.com', msg.as_string())

