#!/usr/bin/env python
# coding: utf-8

# # Execution Module

# ## OKTAToken Access Module

# In[2]:


class OKTAToken:
    # url = "https://jabil.okta.com/oauth2/default/v1/token"
    def __init__(self, url):
        self.url = url
        
    def postaccesstoken(self):
        # importing the requests library
        import requests
        import json
        
        # defining the api-endpoint 
        API_ENDPOINT = self.url
        
        # data to be sent to api
        data = {'grant_type': 'client_credentials',
                'scope': 'access_token',
                'client_id':'0oagwd7ekglCGkNf62p7',
                'client_secret': '-o0zB4nn_j1dbakJQ8jZVH2t77aqPCgNyS0lHqxD'}

        # sending post request and saving response as response object
        r = requests.post(url = API_ENDPOINT, data = data)

        # extracting response text 
        pastebin_url = r.text
        res = json.loads(pastebin_url)
        # print(pastebin_url)
        strtoken = res['access_token']
        return {'access_token': strtoken}
    
class IEDBAPI:
    # url = "https://jabil.okta.com/oauth2/default/v1/token"
    def __init__(self, url, accesstoken, getapi, site, customer, assysku, assyrev):
        self.url = url
        self.accesstoken = accesstoken
        self.getapi = getapi
        self.site = site
        self.customer = customer
        self.assysku = assysku
        self.assyrev = assyrev
        
    def getGRPSummaryReport(self):
        # importing the requests library
        import pandas as pd
        import requests
        import json
        
        # api-endpoint
        URL = self.getapi
        
        # header
        bearertoken = "Bearer " + self.accesstoken
        headers = {"Authorization": bearertoken}

        # defining a params dict for the parameters to be sent to the API
        site = self.site
        customer = self.customer
        division = customer + "*"
        PARAMS = {'site': site,
                  'customer': customer,
                  'division': division}

        # sending get request and saving the response as response object
        r = requests.get(url = URL, headers=headers, params = PARAMS)

        # extracting data in json format
        data = r.text
        json_dict = json.loads(data)
        
        # converting json dictionary to python dataframe for results object
        df = pd.DataFrame.from_dict(json_dict)
        result = df['Result'][0]
        df2 = pd.DataFrame.from_dict(result)
        return df2
    
    def getAssemblyUpdateReport(self):
        # importing the requests library
        import pandas as pd
        import requests
        import json
        
        # api-endpoint
        URL = self.getapi
        
        # header
        bearertoken = "Bearer " + self.accesstoken
        headers = {"Authorization": bearertoken}

        # defining a params dict for the parameters to be sent to the API
        site = self.site
        customer = self.customer
        division = customer + "*"
        PARAMS = {'site': site,
                  'customer': customer,
                  'division': division}
        print(PARAMS)
        try:
            # sending get request and saving the response as response object
            r = requests.get(url = URL, headers=headers, params = PARAMS)

            # extracting data in json format
            data = r.text
            json_dict = json.loads(data)
        
            # converting json dictionary to python dataframe for results object
            df = pd.DataFrame.from_dict(json_dict)
            dfresult = df['Result'][0]
            df2 = pd.DataFrame.from_dict(dfresult)
            result = df2
            # return result
        except requests.exceptions.RequestException as err:
            # Maybe set up for a retry, or continue in a retry loop
            errormsg = str(err)
            result = errormsg
            pass
        except requests.ConnectionError as err:
            # handle ConnectionError the exception
            errormsg = str(err)
            result = errormsg
            pass
        except requests.exceptions.HTTPError as err:
            # handle ConnectionError the exception
            errormsg = str(err)
            result = errormsg
            pass
        except ValueError as err:
            storedfolder = r'\\vnhcmm0ieapp01\Sharedtngo\02_Python_AutoJob\02_Python_IEDB'
            resultlogfname = "iedbassemblyrpt.txt"
            resultpathfile = storedfolder + "\\" +  resultlogfname
            resultotal = ""
            with open(resultpathfile, 'a') as f:
                resultotal = str(err) + '\t\t' + str(r.text)
                f.write(resultotal)
                f.write('\n')
                
            print(resultotal)           
            errormsg = str(err)
            result = errormsg
            pass
            
        return result
    
    def getRawDataReport(self):
        # importing the requests library
        import pandas as pd
        import requests
        import json
        
        # api-endpoint
        URL = self.getapi
        
        # header
        bearertoken = "Bearer " + self.accesstoken
        headers = {"Authorization": bearertoken}

        # defining a params dict for the parameters to be sent to the API
        site = self.site
        customer = self.customer
        division = customer + "*"
        PARAMS = {'site': site,
                  'customer': customer,
                  'division': division,
                  'assembly': assysku,
                  'revision': assyrev}
        try:
            # sending get request and saving the response as response object
            r = requests.get(url = URL, headers=headers, params = PARAMS)

            # extracting data in json format
            data = r.text
            json_dict = json.loads(data)

            # converting json dictionary to python dataframe for results object
            df = pd.DataFrame.from_dict(json_dict)
            df2 = df['Result'][0]
            result = pd.DataFrame.from_dict(df2)
        except requests.exceptions.RequestException as err:
            # Maybe set up for a retry, or continue in a retry loop
            errormsg = str(err)
            result = errormsg
            pass
        except requests.ConnectionError as err:
            # handle ConnectionError the exception
            errormsg = str(err)
            result = errormsg
            pass
        except requests.exceptions.HTTPError as err:
            # handle ConnectionError the exception
            errormsg = str(err)
            result = errormsg
            pass
        except ValueError as err:
            storedfolder = r'\\vnhcmm0ieapp01\Sharedtngo\02_Python_AutoJob\02_Python_IEDB'
            resultlogfname = "iedbassyrawdatarpt.txt"
            resultpathfile = storedfolder + "\\" +  resultlogfname
            resultotal = ""
            with open(resultpathfile, 'a') as f:
                resultotal = str(err) + '\t\t' + str(r.text)
                f.write(resultotal)
                f.write('\n')
                
            print(resultotal)           
            errormsg = str(err)
            result = errormsg
            pass
        
        return result


# ## Find The Old File Module

# In[3]:


class findfiles:
    # need to install !pip install pyxlsb
    def __init__(self, searchfolder, extfile, keynamefile):
        self.searchfolder = searchfolder
        self.extfile = extfile
        self.keynamefile = keynamefile
        
    def foundfiles(self):            
        # **********************************************************************
        # Access folder
        import pandas as pd
        import os
        
        searchkeyname_dict = {}
        listfiles = os.listdir(self.searchfolder)
        # print("Files and directories in '", self.searchfolder, "' :")
        # print(listfiles)       
        
        # **********************************************************************
        # Find specific *.xlsb file
        def isStringFound(x,y):
            try:
                x.upper().index(y.upper())
                return True
            except ValueError:
                return False
            
        searchkeyname_dict['ext'] = self.extfile
        searchkeyname_dict['keyword'] = self.keynamefile
        # print(searchkeyname_dict.keys())
        # print(searchkeyname_dict.values())
        # print(searchkeyname_dict['ext'])
        
        # **********************************************************************
        dictfile = {}
        tuplekey = {'fname','mdate'}
        listfname = []
        listmdate = []
        for x in os.listdir(searchfolder):
            if x.endswith(searchkeyname_dict['ext'][0]):
                pathfile = searchfolder + "\\" +  x
                fileinfor = "File name is: {0}, Modified time is: {1}".format(x,os.path.getmtime(pathfile))
                # print(fileinfor)
                # if x.upper().startswith(searchkeyname_dict['startword'].upper()):
                for y in searchkeyname_dict['keyword']:
                    if(isStringFound(x.upper(),y.upper())):
                        if x not in listfname:
                            listfname.append(x)
                            listmdate.append(os.path.getmtime(pathfile))

        dictfile['fname'] = listfname
        dictfile['mdate'] = listmdate

        # df = pd.DataFrame.from_dict(dictfile)
        return dictfile


# ## IEDB API "AssemblyUpdate" Execution Module

# In[4]:


class IEDBAssemblyUpdate:
    # url = "https://jabil.okta.com/oauth2/default/v1/token"
    def __init__(self, site, customer, division, customerid, assysku, assyrev, assyday, assyunitsmh, assytype):
        self.site = site
        self.customer = customer
        self.division = division
        self.customerid = customerid
        self.assysku = assysku
        self.assyrev = assyrev
        self.assyday = assyday
        self.assyunitsmh = assyunitsmh
        self.assytype = assytype
        
    def accessIEDBCustomerID(self):
        import pandas as pd
        import sqlalchemy as sa
        import urllib
        from sqlalchemy import create_engine, event
        from sqlalchemy.engine.url import URL
        from sqlalchemy.sql import text

        # https://hevodata.com/learn/python-sql-server-integration/
        server = 'vnhcmm0ieapp01\sqlexpress' 
        database = 'IESupportDB' 
        username = 'ie' 
        password = 'J@bil*1111' 

        params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                                         "SERVER="+server+";"
                                         "DATABASE="+database+";"
                                         "UID="+username+";"
                                         "PWD="+password+";")

        engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))

        qry = "SELECT TOP(1) * FROM [IESupportDB].[dbo].[08_IEDB_vs_PLANT_WorkcellID] WHERE IEDBCustomer = '" + self.customer + "' AND IEDBSite = '" + self.site + "' AND IEDBDivision = '" + self.division + "'"

        with engine.connect() as conn:
            rs = conn.execute(qry)
            # dfiedb = pd.DataFrame(rs.fetchall())
            dfiedb = pd.read_sql(qry, con = conn)
        
        return dfiedb
    
    def accessIEDBAssemblyUpdate(self):
        import pandas as pd
        import sqlalchemy as sa
        import urllib
        from sqlalchemy import create_engine, event
        from sqlalchemy.engine.url import URL
        from sqlalchemy.sql import text

        # https://hevodata.com/learn/python-sql-server-integration/
        server = 'vnhcmm0ieapp01\sqlexpress' 
        database = 'IESupportDB' 
        username = 'ie' 
        password = 'J@bil*1111' 

        params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                                         "SERVER="+server+";"
                                         "DATABASE="+database+";"
                                         "UID="+username+";"
                                         "PWD="+password+";")

        engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))

        qry = "SELECT TOP(1) * FROM [IESupportDB].[dbo].[08_IEDB_vs_AssemblyUpdateReportUni] WHERE IEDBCustomerID = '" + str(self.customerid) + "' AND IEDBAssembly = '" + str(self.assysku) + "' AND IEDBRevision = '" + str(self.assyrev) + "'"

        with engine.connect() as conn:
            rs = conn.execute(qry)
            # dfiedb = pd.DataFrame(rs.fetchall())
            dfiedb = pd.read_sql(qry, con = conn)
        
        return dfiedb
    
    def insertIEDBAssemblyUpdateUni(self):
        import pandas as pd
        import sqlalchemy as sa
        import urllib
        from sqlalchemy import create_engine, event
        from sqlalchemy.engine.url import URL
        from sqlalchemy.sql import text
        from sqlalchemy.exc import DataError, IntegrityError
        
        errormsg = "NO"
        # https://hevodata.com/learn/python-sql-server-integration/
        server = 'vnhcmm0ieapp01\sqlexpress' 
        database = 'IESupportDB' 
        username = 'ie' 
        password = 'J@bil*1111' 

        params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                                         "SERVER="+server+";"
                                         "DATABASE="+database+";"
                                         "UID="+username+";"
                                         "PWD="+password+";")

        engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))

        qry = "INSERT INTO [IESupportDB].[dbo].[08_IEDB_vs_AssemblyUpdateReportUni](IEDBCustomerID, IEDBAssembly, IEDBRevision, IEDBLastUpdateDays, IEDBUniteSMH, IEDBType) VALUES ('" + str(self.customerid) + "', '" + str(self.assysku) + "', '" + str(self.assyrev) + "', '" + str(self.assyday) + "', '" + str(self.assyunitsmh) + "', '" + str(self.assytype) + "')"
        
        with engine.connect() as conn:
            try:
                conn.execute(qry)
            except IntegrityError as e:
                # print(e.orig)
                errormsg = e.statement
                pass
        return errormsg + qry
        
    def updateIEDBAssemblyUpdateUni(self):
        import pandas as pd
        import sqlalchemy as sa
        import urllib
        from sqlalchemy import create_engine, event
        from sqlalchemy.engine.url import URL
        from sqlalchemy.sql import text

        # https://hevodata.com/learn/python-sql-server-integration/
        server = 'vnhcmm0ieapp01\sqlexpress' 
        database = 'IESupportDB' 
        username = 'ie' 
        password = 'J@bil*1111' 

        params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                                         "SERVER="+server+";"
                                         "DATABASE="+database+";"
                                         "UID="+username+";"
                                         "PWD="+password+";")

        engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))

        qry = "UPDATE [IESupportDB].[dbo].[08_IEDB_vs_AssemblyUpdateReportUni] SET IEDBLastUpdateDays = '" + str(self.assyday) + "', IEDBUniteSMH = '" + str(self.assyunitsmh) + "', IEDBType = '" + str(self.assytype) + "' WHERE IEDBCustomerID = '" + str(self.customerid) + "' AND IEDBAssembly = '" + str(self.assysku) + "' AND IEDBRevision = '" + str(self.assyrev) + "'"
        # print(qry)
        with engine.connect() as conn:
            conn.execute(qry)
            
    def insertIEDBAssemblyUpdateDup(self):
        import pandas as pd
        import sqlalchemy as sa
        import urllib
        from sqlalchemy import create_engine, event
        from sqlalchemy.engine.url import URL
        from sqlalchemy.sql import text
        from sqlalchemy.exc import DataError, IntegrityError
        
        errormsg = "NO"
        # https://hevodata.com/learn/python-sql-server-integration/
        server = 'vnhcmm0ieapp01\sqlexpress' 
        database = 'IESupportDB' 
        username = 'ie' 
        password = 'J@bil*1111' 

        params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                                         "SERVER="+server+";"
                                         "DATABASE="+database+";"
                                         "UID="+username+";"
                                         "PWD="+password+";")

        engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))

        qry = "INSERT INTO [IESupportDB].[dbo].[08_IEDB_vs_AssemblyUpdateReportDup](IEDBCustomerID, IEDBAssembly, IEDBRevision, IEDBLastUpdateDays) VALUES ('" + str(self.customerid) + "', '" + str(self.assysku) + "', '" + str(self.assyrev) + "', '" + str(self.assyday) + "')"

        with engine.connect() as conn:
            try:
                conn.execute(qry)
            except IntegrityError as e:
                # print(e.orig)
                errormsg = e.statement
                pass
        return errormsg
            
    def deleteIEDBAssemblyUpdate(self):
        import pandas as pd
        import sqlalchemy as sa
        import urllib
        from sqlalchemy import create_engine, event
        from sqlalchemy.engine.url import URL
        from sqlalchemy.sql import text

        # https://hevodata.com/learn/python-sql-server-integration/
        server = 'vnhcmm0ieapp01\sqlexpress' 
        database = 'IESupportDB' 
        username = 'ie' 
        password = 'J@bil*1111' 

        params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                                         "SERVER="+server+";"
                                         "DATABASE="+database+";"
                                         "UID="+username+";"
                                         "PWD="+password+";")

        engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))
        
        qry1 = "DELETE FROM [IESupportDB].[dbo].[08_IEDB_vs_RawDataUni] WHERE IEDBCustomerID = '" + str(self.customerid) + "'"
        qry2 = "DELETE FROM [IESupportDB].[dbo].[08_IEDB_vs_RawDataDup] WHERE IEDBCustomerID = '" + str(self.customerid) + "'"
        qry3 = "DELETE FROM [IESupportDB].[dbo].[08_IEDB_vs_AssemblyUpdateReportUni] WHERE IEDBCustomerID = '" + str(self.customerid) + "'"
        qry4 = "DELETE FROM [IESupportDB].[dbo].[08_IEDB_vs_AssemblyUpdateReportDup] WHERE IEDBCustomerID = '" + str(self.customerid) + "'"
        with engine.connect() as conn:
            # conn.execute(qry1)
            # print(qry1)
            # conn.execute(qry2)
            # print(qry2)
            conn.execute(qry3)
            print(qry3)
            conn.execute(qry4)
            print(qry4)
            
# iedbCustomerAPI = IEDBCustomerID('HCM','HCM_CALIX','HCM_CALIX*','','','','','','')
# apiCustomerres = iedbCustomerAPI.accessIEDBCustomerID()
# print(apiCustomerres['IEDBCustomerID'][0])


# # Iterate The IEDB Workcel Division

# In[5]:


import pandas as pd
import sqlalchemy as sa
import urllib
from sqlalchemy import create_engine, event
from sqlalchemy.engine.url import URL
from sqlalchemy.sql import text

from datetime import datetime
from openpyxl import Workbook
from openpyxl import load_workbook

# log data time start time report
dtStartProgress = datetime.now()

# log data time report
now = datetime.now()
# dd/mm/YY H:M:S
dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
dt_string2 = now.strftime("%Y%m%d_%H%M%S")
storedfolder = r'\\vnhcmm0ieapp01\Sharedtngo\02_Python_AutoJob\02_Python_IEDB'
resultlogfname = "iedbassemblyrpt.txt"
resultpathfile = storedfolder + "\\" +  resultlogfname
open(resultpathfile, 'w').close()

# https://hevodata.com/learn/python-sql-server-integration/
server = 'vnhcmm0ieapp01\sqlexpress' 
database = 'IESupportDB' 
username = 'ie' 
password = 'J@bil*1111' 

params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                                 "SERVER="+server+";"
                                 "DATABASE="+database+";"
                                 "UID="+username+";"
                                 "PWD="+password+";")

engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))

qry = "SELECT * FROM [IESupportDB].[dbo].[08_IEDB_vs_PLANT_WorkcellID] ORDER BY IEDBCustomerID"

with engine.connect() as conn:
    rs = conn.execute(qry)
    # dfiedb = pd.DataFrame(rs.fetchall())
    dfiedb = pd.read_sql(qry, con = conn)


# # ETL: IEDB Assembly Update From IEDB

# In[8]:


from datetime import datetime
import pandas as pd
import time

storedfolder = r'\\vnhcmm0ieapp01\Sharedtngo\02_Python_AutoJob\02_Python_IEDB'
resultlogfname = "iedbassemblyrpt.txt"
resultpathfile = storedfolder + "\\" +  resultlogfname
open(resultpathfile, 'w').close()

apiresult = 'PASS'
apieachresult = 'PASS'
for index, row in dfiedb.iterrows():
    # log data time report
    now = datetime.now()
    dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
    
    customer = row['IEDBCustomer'].strip()
    site = row['IEDBSite'].strip()
    division = row['IEDBDivision'].strip()
    wcid = row['PLWorkcellID']
        
    errormsg = "NO"
    resultotal = ""
    
    # Access The IEDBAssemblyUpdate
    sqlCustomer = IEDBAssemblyUpdate(site, customer, division,'','','','', '', '')
    sqlCustomerRes = sqlCustomer.accessIEDBCustomerID()
    intCustomerID = sqlCustomerRes['IEDBCustomerID'][0]
    # print(str(intCustomerID) + ": " + customer)
    print()
    print('Start Working On Customer: ' + str(customer) + ' - CustomerID: ' + str(intCustomerID))
    time.sleep(15)
    
    x = customer.find('_')
    cust = customer[(x+1):len(customer)] 

    try:
        # access OKTA token
        url = "https://jabil.okta.com/oauth2/default/v1/token"
        oktatoken = OKTAToken(url)
        accesstoken = oktatoken.postaccesstoken()
        
        # **************************************************************************
        # **************************************************************************
        # execute GetGRPSummaryReport IEDB API
        getapi = "https://iedb2api-prd.jblapps.com/api/Report/GetGRPSummaryReport"
        iedbapi = IEDBAPI(url, accesstoken['access_token'], getapi, site, customer, '', '')
        apires = iedbapi.getGRPSummaryReport()
        
        namefile = cust + "_GRPSummaryRpt_" + dt_string2 + ".xlsx"
        # converting json dictionary to python dataframe for results object
        apires.to_excel(storedfolder + "\\" + namefile)

        # access to workbook
        wb = load_workbook(storedfolder + "\\" + namefile)
        # change the name of Worksheet to “Changed Sheet”
        ws =  wb.active
        ws.title = cust + "_GRPSummaryRpt"

        # Save a file as sample_book.xlsx with save function.
        filename = storedfolder + "\\" + namefile
        wb.save(filename = filename)
        
        with open(resultpathfile, 'a') as f:
            resultotal = dt_string + '\t' + "PASS" + '\t' + cust + "_GRPSummaryRpt"
            f.write(resultotal)
            f.write('\n')
        print(resultotal)
        
        # **************************************************************************
        # **************************************************************************
        # execute GetAssemblyUpdateReport IEDB API
        getapi = "https://iedb2api-prd.jblapps.com/api/Report/GetAssemblyUpdateReport"
        iedbapi = IEDBAPI(url, accesstoken['access_token'], getapi, site, customer, '', '')
        apiCustomerRes = iedbapi.getAssemblyUpdateReport()
        print(type(apiCustomerRes))
        if (isinstance(apiCustomerRes,str)):
            errormsg = dt_string + '\t' + "FAIL" + '\t' + cust + "_AssemblyUpdateRpt" + '\t\t' + str(apiCustomerRes)
            # write overall result to txt file
            with open(resultpathfile, 'a') as f:
                resultotal = errormsg
                f.write(resultotal)
                f.write('\n')
            print(errormsg)
            time.sleep(60)
            # break
        elif(isinstance(apiCustomerRes,pd.DataFrame)):
            namefile = cust + "_AssemblyUpdateRpt_" + dt_string2 + ".xlsx"
            # converting json dictionary to python dataframe for results object
            apiCustomerRes.to_excel(storedfolder + "\\" + namefile)
            
            # Delete The Current IEDBCustomerID In Database
            iedbDeleteCustomerAPI = IEDBAssemblyUpdate('', '', '', intCustomerID, '', '', '', '', '')
            iedbDeleteCustomerAPI.deleteIEDBAssemblyUpdate()
            print("Delete Assembly Report And Raw Data By IEDBCustomerID: **" + str(intCustomerID) + "** Successfully!")

            # populate to sqlserver
            # print(apiCustomerRes)
            for idxapi, rowapi in apiCustomerRes.iterrows():
                assysku = str(rowapi['Assembly']).strip().replace("'","")
                assyrev = str(rowapi['Revision']).strip().replace("'","")
                assyday = rowapi['LastUpdateDays']
                assyunitsmh = rowapi['UniteSMH']

                assystopwatch = rowapi['StopWatch']
                assymost = rowapi['Most']
                assyestimate = rowapi['Estimate']
                assytype = 'Estimate'
                if(assystopwatch > 0):
                    assytype = 'StopWatch'
                elif(assymost  > 0):
                    assytype = 'Most'
                else:
                    assytype = 'Estimate'

                iedbCustomerAPI = IEDBAssemblyUpdate('', '', '', intCustomerID, assysku, assyrev, assyday, assyunitsmh, assytype)
                dfIEDBAssemblyUpdate = iedbCustomerAPI.accessIEDBAssemblyUpdate()
                assydayindb = 0
                if (len(dfIEDBAssemblyUpdate) > 0):
                    assydayindb = dfIEDBAssemblyUpdate['IEDBLastUpdateDays']
                    errormsg = iedbCustomerAPI.insertIEDBAssemblyUpdateDup()
                    if(errormsg != "NO"):
                        print
                        break
                    # print(str(assysku) + ': ' + 'assyday: ' + str(assyday) + '\t' + ' assydayindb: ' + str(assydayindb))
                    if(int(assyday) > int(assydayindb)):
                        # print(str(assysku) + ': ' + 'assyday: ' + str(assyday) + '\t' + ' assydayindb: ' + str(assydayindb))
                        iedbCustomerAPI.updateIEDBAssemblyUpdateUni()                            
                else:
                    # errormsg = iedbCustomerAPI.insertIEDBAssemblyUpdateUni()
                    iedbCustomerAPI.insertIEDBAssemblyUpdateUni()
                    if(errormsg != "NO"):
                        break
                        
        if(errormsg == "NO"):
            # access to workbook
            wb = load_workbook(storedfolder + "\\" + namefile)
            # change the name of Worksheet to “Changed Sheet”
            ws =  wb.active
            ws.title = cust + "_AssemblyUpdateRpt"

            # Save a file as sample_book.xlsx with save function.
            filename = storedfolder + "\\" + namefile
            wb.save(filename = filename)

            # write overall result to txt file
            with open(resultpathfile, 'a') as f:
                resultotal = dt_string + '\t' + "PASS" + '\t' + cust + "_AssemblyUpdateRpt"
                f.write(resultotal)
                f.write('\n')
        else:
            apieachresult = 'FAIL_errormsg'
            # write overall result to txt file
            with open(resultpathfile, 'a') as f:
                resultotal = dt_string + '\t' + "FAIL" + '\t' + cust + "_AssemblyUpdateRpt" + '\t\t' + str(errormsg)
                f.write(resultotal)
                f.write('\n')
            print(resultotal)
    except ValueError as err:
        apieachresult = 'FAIL_ValueError'
        # write overall result to txt file
        with open(resultpathfile, 'a') as f:
            resultotal = dt_string + '\t' + "FAIL" + '\t' + cust + "_AssemblyUpdateRpt"+ '\t\t' + str(err)
            f.write(resultotal)
            f.write('\n')
        print(resultotal)
            
    if(apieachresult == 'FAIL'):
        apiresult = 'FAIL'
    print(resultotal)
    
dtEndProgress = datetime.now()
diffexetime = (dtEndProgress - dtStartProgress).total_seconds()
with open(resultpathfile, 'a') as f:
    f.write("dtStartProgress: " + '\t' + dtStartProgress.strftime("%d/%m/%Y %H:%M:%S") + '\t\t' + "dtEndProgress: " + dtEndProgress.strftime("%d/%m/%Y %H:%M:%S") + '\t\t' + "diffexetime: " + str(diffexetime) + " (secs)")
    f.write('\n')


# # Run The Module 1.2 To Remove Old File > 1 Month

# In[ ]:


from datetime import datetime

if(apiresult == 'PASS'):
    import os
    import time
    from datetime import datetime

    dtnow = datetime.now()
    # time.time() returns the actual time in seconds.
    # os.stat(filename).st_mtime returns the time of last modification in seconds.
    tnow = time.time()
    searchfolder = r'\\vnhcmm0ieapp01\Sharedtngo\02_Python_AutoJob\02_Python_IEDB'
    
    extfile = ['xlsx']
    keynamefile = ['GRPSummaryRpt', '2022']
    
    resultfiles = findfiles(searchfolder, extfile, keynamefile)
    result = resultfiles.foundfiles()
    for v in result['fname']:
        filename = v
        path = os.path.join(searchfolder, filename)
        if (tnow - os.stat(path).st_mtime) > 604800:
            os.remove(path)
            
dtEndProgress = datetime.now()
diffexetime = (dtEndProgress - dtStartProgress).total_seconds()
with open(resultpathfile, 'a') as f:
    f.write("dtStartProgress: " + '\t' + dtStartProgress.strftime("%d/%m/%Y %H:%M:%S") + '\t\t' + "dtEndProgress: " + dtEndProgress.strftime("%d/%m/%Y %H:%M:%S") + '\t\t' + "diffexetime: " + str(diffexetime) + " (secs)")
    f.write('\n')


# # SMTP Email Progress

# In[9]:


import os
import smtplib
from smtplib import SMTP
from email import encoders
from email.message import Message
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from datetime import datetime

# date = date.strftime("%Y-%m-%d")  # convert to format yyyy-mm-dd

# print(message)
# we will built the message using the email library and send using smtplib
msg = MIMEMultipart('alternative')
msg['Subject'] = "IEDB GetGRPSummaryReport Python - " + dt_string   # set email subject

directory = r"\\vnhcmm0ieapp01\Sharedtngo\02_Python_AutoJob\02_Python_IEDB"
filename = "iedbassemblyrpt.txt"
path = os.path.join(directory, filename)
img = MIMEImage(open(path, 'rb').read(), _subtype="txt")
img.add_header('Content-Disposition', 'attachment', filename=filename)
msg.attach(img)

# write an email message
message = ''
count = 0
with open(path) as f:
    for line in f:
        count += 1
        message = message + '\n' + str(count) + '\t' + line

part = MIMEText(message,'plain')
msg.attach(part)
       
# we will send via outlook, first we initialise connection to mail server
# smtp = smtplib.SMTP('smtp-mail.outlook.com', '587')
with SMTP("corimc04.corp.jabil.org") as smtp:
    smtp.ehlo()  # say hello to the server
    smtp.starttls()  # we will communicate using TLS encryption
       
    # login to outlook server, using generic email and password
    # smtp.login('Alex@outlook.com', 'Alex123')
       
    # send email to our boss
    smtp.sendmail('noreply_autopyiedb_GRPSummaryRpt@jabil.com', 'truong_ngo@jabil.com', msg.as_string())


# # Clean File For Next IEDB Raw Data

# In[1]:


storedfolder = r'\\vnhcmm0ieapp01\Sharedtngo\02_Python_AutoJob\02_Python_IEDB'
resultlogfname = "iedbassyrawdatarpt.txt"
resultpathfile = storedfolder + "\\" +  resultlogfname
open(resultpathfile, 'w').close()

